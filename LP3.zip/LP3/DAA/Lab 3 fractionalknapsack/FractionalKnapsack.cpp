#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Item {
    double weight;
    double value;
    
    Item(double w, double v) : weight(w), value(v) {}
};

// Comparison function to sort items by value-to-weight ratio
bool compare(const Item& a, const Item& b) {
    return (a.value / a.weight) > (b.value / b.weight);
}

double fractionalKnapsack(const vector<double>& weights, const vector<double>& values, double capacity) {
    if (weights.size() != values.size()) {
        throw invalid_argument("Weights and values must be of the same length.");
    }
    
    double res = 0;
    vector<Item> items;
    for (size_t i = 0; i < weights.size(); ++i) {
        items.emplace_back(weights[i], values[i]);
    }
    
    // Sort items by descending value-to-weight ratio
    sort(items.begin(), items.end(), compare);
    
    for (const auto& item : items) {
        if (capacity <= 0) {
            break;
        }
        if (item.weight > capacity) {
            res += capacity * (item.value / item.weight);
            capacity = 0;
        } else {
            res += item.value;
            capacity -= item.weight;
        }
    }
    
    return res;
}

int main() {
    int numItems;
    cout << "Enter the number of items: ";
    cin >> numItems;

    vector<double> weights(numItems);
    cout << "Enter the weights (space-separated): ";
    for (int i = 0; i < numItems; ++i) {
        cin >> weights[i];
    }

    vector<double> values(numItems);
    cout << "Enter the values (space-separated): ";
    for (int i = 0; i < numItems; ++i) {
        cin >> values[i];
    }

    if (weights.size() != static_cast<size_t>(numItems) || values.size() != static_cast<size_t>(numItems)) {
        throw invalid_argument("The number of weights and values must match the number of items.");
    }

    double capacity;
    cout << "Enter the capacity of the knapsack: ";
    cin >> capacity;

    double maxValue = fractionalKnapsack(weights, values, capacity);
    cout << "Maximum value in the knapsack: " << maxValue << endl;

    return 0;
}


/*Example:
Input:


Enter the number of items: 3
Enter the weights (space-separated): 10 20 30
Enter the values (space-separated): 60 100 120
Enter the capacity of the knapsack: 50
Output:


Maximum value in the knapsack: 240
How It Reaches the Solution:
It calculates the value-to-weight ratios for the items:
Item 1: 60/10 = 6
Item 2: 100/20 = 5
Item 3: 120/30 = 4
It sorts the items by these ratios.
With a capacity of 50:
Takes all of Item 1 (10 weight, 60 value).
Takes all of Item 2 (20 weight, 100 value).
For Item 3, only 20 units of its weight can fit, so it takes 20/30 of its value (80).
Total Value = 60 + 100 + 80 = 240




*/
