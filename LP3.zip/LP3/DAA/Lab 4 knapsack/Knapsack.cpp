#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// Function to solve the 0/1 Knapsack problem using dynamic programming
int knapSack(int W, vector<int> &weights, vector<int> &values, int items)
{
    // Create a table to store maximum profit values for subproblems
    vector<vector<int>> table(items + 1, vector<int>(W + 1, 0));

    // Build the table in a bottom-up manner
    for (int i = 0; i <= items; i++)
    {
        for (int w = 0; w <= W; w++)
        {
            if (i == 0 || w == 0)
            {
                table[i][w] = 0; // Base case: no items or no capacity
            }
            else if (weights[i - 1] <= w)
            {
                // If the current item's weight is less than or equal to the current capacity
                table[i][w] = max(values[i - 1] + table[i - 1][w - weights[i - 1]], table[i - 1][w]);
            }
            else
            {
                // If the current item's weight is greater than the current capacity
                table[i][w] = table[i - 1][w];
            }
        }
    }

    // The bottom-right cell contains the maximum profit
    return table[items][W];
}

int main()
{
    int n, W;

    // Input values and weights
    cout << "Enter number of items: ";
    cin >> n;

    vector<int> values(n), weights(n);

    cout << "Enter values of items (space-separated): ";
    for (int i = 0; i < n; i++)
    {
        cin >> values[i];
    }

    cout << "Enter weights of items (space-separated): ";
    for (int i = 0; i < n; i++)
    {
        cin >> weights[i];
    }

    cout << "Enter Knapsack Capacity: ";
    cin >> W;

    // Call knapSack function to get the maximum profit
    int maxProfit = knapSack(W, weights, values, n);

    // Output the result
    cout << "Maximum profit that can be achieved: " << maxProfit << endl;

    return 0;
}
/*Example:
Input:
mathematica
Copy code
Enter number of items: 3
Enter values of items (space-separated): 60 100 120
Enter weights of items (space-separated): 10 20 30
Enter Knapsack Capacity: 50
Step-by-Step Execution:
Initialize Table:

Create a 4 x 51 table (for 3 items + 1 and capacity 50 + 1).
The table initially has all zeros because if the capacity or number of items is 0, the profit is 0.
Filling the Table:

For each item and each weight capacity:
Item 1 (weight=10, value=60):

For capacities 10 to 50, the item can fit, so the table entries for these capacities are 60.
Item 2 (weight=20, value=100):

For capacities 20 to 30, the best option is to include only Item 2, so values for these capacities become 100.
For capacities 30 to 50, both Item 1 and Item 2 can fit, so the value becomes 160 (60 + 100).
Item 3 (weight=30, value=120):

For capacity 30, choosing only Item 3 gives a profit of 120.
For capacity 50, choosing Items 2 and 3 gives a maximum profit of 220 (100 + 120).
Result:

The bottom-right cell (table[3][50]) contains the maximum profit achievable: 220.
Final Output:
yaml
Copy code
Maximum profit that can be achieved: 220
Summary:
This program calculates the optimal selection of items for the knapsack, ensuring maximum profit without exceeding the weight limit. It uses a table to store intermediate solutions, making it efficient by avoiding redundant calculations.*/